#FAURE Héloïse et LEMAIRE Théo
# G1 

from time import*
from math import *
from random import *
from jeu_joueur import *
from jeu_ordi import *
from regle_jeu import *
from interface_graphique import *
from carte import *
from pile_carte import*
from turtle import*

interface_graphique_fixe()

up()
goto(-360,0)
down()
color("orange")
textinput("BIENVENUE", "BONJOUR ET BIENVENUE AU POLYTECH CASINO! Appuyez sur la touche entrer pour jouer")

#difficulté de l'ordinateur
ordi=numinput("Choix de la difficulté","Veuillez taper le 1 si vous voulez un ordi faible ou le 2 si vous voulez un ordi moyen ")
while ordi!=1 and ordi!=2:
    ordi=numinput("ERREUR"," Veuillez choisir 1 ou 2")
    
#on demande à l'utilisateur les trois chiffres qui définissent les règles
regle = regle_jeu()

# x le nombre de cartes
x=randint(15,30)
pile_carte(-500,205,x)

# on affiche le nombre de cartes restantes sur le tapis de jeu
color("black")
up()
goto(-100,-250)
down()
write("il reste      carte(s) sur la table", font=("Arial", 15, "normal"))
up()
goto(-37,-250)
down()
write(x,font=("Arial", 15,"normal"))

#démarrage du jeu 
joueur=textinput("Le jeu commence!", "voulez-vous commencer ? oui ou non?")
while joueur!="oui" and joueur!="non":
    joueur=textinput("ERREUR","je n'ai pas compris, veuillez repondre 'oui' ou 'non' à la question 'Voulez vous commencer?'")
if joueur=="oui":
    while x!=0:      #ces fonctions ci dessous return le nombre de cartes une fois que le joueur ou l'ordinateur a joué (nombre de cartes stocké dans la variable x)
        x=jeu_joueur(x,regle)
        if x!=0:
            x=jeu_ordi(x,regle,ordi)
elif joueur=="non":
    while x!=0:
        x=jeu_ordi(x,regle,ordi)
        if x!=0:
            x=jeu_joueur(x,regle)


