#FAURE Héloïse et LEMAIRE Théo
# G1 


from turtle import*

#design de la main
def main(x,y,l,L):
    up()             # le début de la main
    goto(x,y)
    forward(-l/4)
    left(90)
    down()
    begin_fill()
    color("sandybrown")
    forward(L/5)
    right(90)
    circle(l/4,90)
    forward((3*L/5)-(l/4))
    i=0

    while i<3:           # les doigts de la main
        circle((l/8),180)
        forward((3/10)*L)
        backward((3/10)*L)
        left(180)
        i=i+1
    circle((l/8),180)
    forward((3/10)*L)
    right(125)
    forward(2*L/10)
    circle((l/8),180)
    forward((3/10)*L)
    right(55)
    forward((L/5)-(3*l/8))
    circle(l/4,90)
    right(90)
    forward(L/5)
    left(90)
    end_fill()
    
    up()            # le contour de la carte en noir
    goto(x,y)
    forward(-l/4)
    left(90)
    down()
    color("black")
    forward(L/5)
    right(90)
    circle(l/4,90)
    forward((3*L/5)-(l/4))
    i=0
    while i<3:
        circle((l/8),180)
        forward((3/10)*L)
        backward((3/10)*L)
        left(180)
        i=i+1
    circle((l/8),180)
    forward((3/10)*L)
    right(125)
    forward(2*L/10)
    circle((l/8),180)
    forward((3/10)*L)
    right(55)
    forward((L/5)-(3*l/8))
    circle(l/4,90)
    right(90)
    forward(L/5)

    left(90)             #les manches de la chemise
    begin_fill()
    color("white")
    forward(L/4)
    right(90)
    forward(l/8)
    right(90)
    forward(L/4)
    right(90)
    forward(l/8)
    end_fill()

    backward(l/8)       #les manches du costume 
    right(90)
    begin_fill()
    color("black")
    forward(L/4)
    right(90)
    forward(l/8)
    right(90)
    forward(L/4)
    right(90)
    forward(l/8)
    end_fill()


