#FAURE Héloïse et LEMAIRE Théo
#G1

from turtle import*

# cette fonction dessine un rectangle, fonction utilisée dans plusieurs fonctions du jeu
def rectangle(x,y,longueur,largeur):
    up()
    goto(x,y)
    down()
    i=0
    while i<2:
        forward(longueur)
        left(90)
        forward(largeur)
        left(90)
        i=i+1
    right(90)

def tapis(x,y):
    
    color("green")   # le rectange vert
    begin_fill()
    rectangle(-650,-325,1300,655)
    end_fill()

    color("brown")   # le rectangle marron
    up()
    goto(-650,-325)
    down()
    width(20)
    forward(4)
    left(90)
    rectangle(-650,-325,1300,655)
    
    color("black")   # le rectangle noir
    width(2)
    left(90)
    rectangle(-525,-200,1050,425)
    left(90)
    up()
    goto(-300,-200)
    down()
    
    color("green")   # texte polytech casino
    forward(600)
    left(180)
    up()
    forward(450)
    down()
    color("black")
    write("PolytechCasino", font=("Lucida Handwriting", 25 , "normal"))




