#FAURE Héloïse et LEMAIRE Théo
#G1


from turtle import*
from tapis import*

#design de la carte
def carte(x,y,taille): 
    color("black")            #contour de la carte
    width(2)
    rectangle(x+1,y,0.73*taille+1,taille+1)
    left(90)

    width(1)
    color("white")
    begin_fill()
    rectangle(x,y+2,0.73*taille,taille)
    left(90)
    end_fill()

    color("red")           #intérieur de la carte
    begin_fill()
    rectangle(x+0.1*taille,y+0.1*taille,0.54*taille,0.8*taille)
    right(180)
    end_fill()

    up()                   #cercle central
    forward(0.18*taille)
    right(90)
    forward(0.27*taille)
    down()
    color("white")
    begin_fill()
    circle(taille*0.22,360)
    end_fill()
    
    color("black")            #étoile centrale
    up()
    left(180)
    forward(0.03*taille)
    right(90)
    down()
    begin_fill()
    z=0
    while z<5:
        forward(0.45*taille)
        right(160)
        forward(0.45*taille)
        right(160)
        z=z+1
    end_fill()

    up()                 #4 points dans les coins
    left(95)
    forward(0.27*taille)
    down()
    color("black")
    begin_fill()
    circle(0.02*taille,360)
    end_fill()
    up()
    left(150)
    forward(0.40*taille)
    down()
    begin_fill()
    circle(0.02*taille,360)
    end_fill()
    up()
    left(92)
    forward(0.73*taille)
    down()
    begin_fill()
    circle(0.02*taille,360)
    end_fill()
    up()
    left(90)
    forward(0.40*taille)
    down()
    begin_fill()
    circle(0.02*taille,360)
    end_fill()
    up()
    goto(x,y)
    left(3)
    down()

    
