#FAURE Héloïse et LEMAIRE Théo
# G1 


from carte import*
from turtle import*

# cette fonction positionne les cartes sur le tapis de jeu
def pile_carte(x,y,nb):
    seth(0)
    up()
    goto(x,y)
    down()
    nbcarte=0
    a=0
    b=0
    c=0
    while nbcarte<nb:
        if nbcarte<=9:
            carte(x+a,y-100,100)
            a=a+100
        elif nbcarte<=19 and nbcarte>=10:
            carte(x+b,y-230,100)
            b=b+100
        else:
            carte(x+c,y-360,100)
            c=c+100
        nbcarte=nbcarte+1

