#FAURE Héloïse et LEMAIRE Théo
# G1 


# cette fonction affiche si le joueur a gagné ou perdu à la fin de la partie
from turtle import*
def resultats(r):
    up()
    goto(-400,-100)
    down()
    color("red")
    write(r, font=("Arial Black",150 , "normal"))
            

