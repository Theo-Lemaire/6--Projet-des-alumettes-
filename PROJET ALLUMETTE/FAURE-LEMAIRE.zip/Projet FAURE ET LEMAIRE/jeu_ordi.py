#FAURE Héloïse et LEMAIRE Théo
# G1 


from time import*
from random import *
from resultats import*
from suppression import*
from affichage_ordi import*


#l'ordinateur est faible, il joue des chiffres aléatoires
def jeu_ordi_faible(x,regle):
    #si le nombre de cartes sur la table est inférieur au nombre de cartes que l'on peut retirer, alors le jeu s'arrète: égalité
    if x-regle[0]<0 and x-regle[1]<0 and x-regle[2]<0:
        resultats("égalité")
        return 0 
    else:        #sinon l'ordi joue normalement et de façon aléatoire
        coup=randint(0,2)
        while x-regle[coup]<0:
            coup=randint(0,2) 
        supprime(-500,200,regle[coup],x)     # la fonction supprime permet de retirer les cartes du tapis de jeu
        x=x-regle[coup]

        affichage_ordi(x,regle[coup])        # la fonction affiche permet d'afficher sur le tapis de jeu ce que l'ordinateur vient de jouer
       
        if x==0:
            resultats("PERDU!")
            return(x)
        else:
            return(x)
        
#l'ordinateur est moyen
def jeu_ordi_moyen(x,regle): 
    if x-regle[0]<0 and x-regle[1]<0 and x-regle[2]<0:
        resultats("égalité")
        return 0
    else:        # l'ordinateur est un minimum intelligent, si il reste le même nombre de cartes sur la table que le nombre de cartes autorisé à retirer,
                 # il prend ce nombre de carte
        coup=coup_moyen(x,regle)      # la fonction coup_moyen représente l'intelligence de l'ordinateur
        supprime(-500,200,regle[coup],x)
        x=x-regle[coup]

        affichage_ordi(x,regle[coup])
        
        if x==0:
            resultats("PERDU!")
            return(x)
        else:
            return(x)


# Si il y a x cartes sur la table, et que l'on peut en retirer x alors l'ordinateur va retirer x cartes non (aléatoirement)
def coup_moyen(x,regle):
    if x==regle[0]:
        return 0
    elif x==regle[1]:
        return 1
    elif x==regle[2]:
        return 2
    else:
        coup=randint(0,2)
        while x-regle[coup]<0:
            coup = randint(0,2)
        return coup

# lors de jouer, le joueur choisit si il veut un ordinateur faible ou un ordinateur moyen
def jeu_ordi(x,regle,ordi):
    sleep(3)
    if ordi==1:
        return jeu_ordi_faible(x,regle)
    if ordi==2:
        return jeu_ordi_moyen(x,regle)
