#FAURE Héloïse et LEMAIRE Théo
# G1 


from resultats import*
from suppression import*
from tapis import*

def jeu_joueur(x,regle):
    
    #si le nombre de cartes sur la table est inférieur au nombre de cartes que l'on peut retirer alors: égalité le jeu s'arrète
    if x-regle[0]<0 and x-regle[1]<0 and x-regle[2]<0:
        resulats("égalité")
        return 0
    
    #si le joueur ne retire pas le bon nombre de cartes autorisé, il réessaye jusqu'à ce que le chiffre appartienne à la règle du jeu
    else:
        choix=int(numinput("Choix des cartes","combien de cartes voullez vous enlever ?"))
        while((choix!=regle[0]) and (choix!=regle[1]) and (choix!=regle[2])) or (x-choix<0):
            choix=int(numinput("ERREUR","vous ne pouvez pas choisir ce nombre, choisissez-en un autre. Autre choix ?")) 
        supprime(-500,200,choix,x)   #la fonction supprime permet de retirer les cartes du tapis du jeu
        x=x-choix
        if x==0:
            resultats("GAGNE!")
            return(x)
        else:
            return (x)
