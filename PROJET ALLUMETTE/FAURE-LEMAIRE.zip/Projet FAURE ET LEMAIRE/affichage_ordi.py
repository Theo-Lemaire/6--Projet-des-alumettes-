#FAURE Héloïse et LEMAIRE Théo
# G1


from tapis import*

# cette fonction affiche ce que l'ordinateur a joué en haut à gauche 
def affichage_ordi(x,b):
    color("green")
    begin_fill()
    rectangle(-37,-250,20,20)
    end_fill()
    color("black")
    write(x, font=("Arial", 15, "normal"))
    
    up()
    goto(190,280)
    down()
    color("black")
    write(" L'ordinateur a pris     carte(s)", font=("Arial", 15 , "normal"))

    # ceci permet d'afficher à chaque fois le nombre cartes (en supprimant, recouvrant de vert le nombre précédent) joué par l'ordinateur
    color("green")
    left(180)
    begin_fill()
    rectangle(380,280,20,20)
    end_fill()
    up()
    goto(365,280)
    down()
    color("black")
    write(b, font=("Arial", 15, "normal"))
        

