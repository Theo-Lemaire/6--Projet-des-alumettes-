#FAURE Héloïse et LEMAIRE Théo
# G1 

from turtle import*
from random import*


def regle_jeu():
    r=randint(1,3)
    if r==1:
        regle=[1,2,3]
    elif r==2:
        regle=[1,3,5]
    elif r==3:
        regle=[1,4,5]
    else:
        regle=[2,4,6]
    
    up()
    goto(-100,-300)
    down()
    write("Les regles sont",font=("Arial",15,"normal"))
    up()
    goto(50,-300)
    down()
    write(regle,font=("Arial",15,"normal"))

    return regle


###le joueur choisit lui même la règle à laquelle il veut jouer ( =le nombre de cartes autorisé à retirer)
##def regle_jeu():
##    regle=[]
##    i=0
##    nb_regle=randint(3,4)
##    while i<nb_regle:
##        r=randint(1,9)
##        regle.append(r)
##
##    return regle
