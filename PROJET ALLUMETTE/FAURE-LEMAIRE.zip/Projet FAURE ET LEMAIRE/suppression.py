#FAURE Héloïse et LEMAIRE Théo
#G1


from pile_carte import *
from tapis import *

# cette fonction permet de retirer les cartes du tapis de jeu lorsque l'ordinateur et le joueur ont joué
def supprime(x,y,choix,nb):
    color("green")
    i=0
    while i<choix:
        if nb>20:
            begin_fill()
            rectangle(x+(nb-21)*100,y-360,85,110)
            left(90)
            end_fill()
        elif nb<=20 and nb>10:
            begin_fill()
            rectangle(x+(nb-11)*100,y-230,85,110)
            left(90)
            end_fill()
        else:
            begin_fill()
            rectangle(x+(nb-1)*100,y-100,85,110)
            end_fill()
            left(90)
        nb=nb-1
        i=i+1



